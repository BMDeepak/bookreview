package com.jsp.BookReviewer.model;

public enum UserRole {
	ADMIN,
	CONTRIBUTOR;
}
