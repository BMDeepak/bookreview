package com.jsp.BookReviewer.model;

public enum Genre {
	BIOGRAPHY,
	AUTOGRAPHY,
	SELFDEVELOPMENT,
	FICTION,
	FANTACY,
	EVOLUTION,
	HISTORY;
}
