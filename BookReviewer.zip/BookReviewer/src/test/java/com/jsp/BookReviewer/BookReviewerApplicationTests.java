package com.jsp.BookReviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookReviewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
