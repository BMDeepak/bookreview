package com.jsp.BookReviewer.serviceimpl;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.jsp.BookReviewer.dto.ReviewResponse;
import com.jsp.BookReviewer.model.Review;
import com.jsp.BookReviewer.repository.ReviewRepository;
import com.jsp.BookReviewer.service.ReviewService;
import com.jsp.BookReviewer.util.ResponseStructure;

public class ReviewServiceImpl implements ReviewService{
	@Autowired
	ResponseStructure<ReviewResponse> responseStructure;
	@Autowired
	private ReviewRepository reviewRepository;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired

	@Override
	public ResponseEntity<ResponseStructure<ReviewResponse>> saveReview(RequestBody requestBody, int reviewId) {
		Optional<Review> optional = reviewRepository.findById(reviewId); 
		if(optional.isPresent()) {
			Review review = mapper.map(optional, Review.class);
			review = reviewRepository.save(review);	
			ReviewResponse reviewResponse = mapper.map(review, ReviewResponse.class);
			responseStructure.setData(reviewResponse);
			responseStructure.setMessage("saved review successfully");
			responseStructure.setStatus(HttpStatus.CREATED.value());
			
		}
		return null;
	}

}
